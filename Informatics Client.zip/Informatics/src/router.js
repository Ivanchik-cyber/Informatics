import { createWebHistory, createRouter } from "vue-router"

const routes = [
  {
    path: "/",
    name: "login",
    component: () => import("./components/Registration_Form.vue")
  },
  {
    path: "/main",
    name: "main",
    component: () => import("./components/Main_Page.vue")
  },
  {
    path: "/lesson1/:difficult",
    name: "first_lesson",
    component: () => import("./components/Lesson_Telephon.vue")
  },
  {
    path: "/lesson2/:difficult",
    name: "second_lesson",
    component: () => import("./components/Lesson_MAX.vue")
  },
  {
    path: "/lesson3/:difficult",
    name: "third_lesson",
    component: () => import("./components/Lesson_Marketplace.vue")
  },
  {
    path: "/lesson4/:difficult",
    name: "fourth_lesson",
    component: () => import("./components/Lesson_Gosuslugi.vue")
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
