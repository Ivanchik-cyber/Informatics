<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  // Импорт
  import {ref, watch} from "vue"
  import VueCookies from "vue-cookies"
  import {useRoute, useRouter} from "vue-router"
  import UsersDatabase from "./services/UsersDatabase"
  import Header from "./elements/Header_Element.vue"

  // Получение метаданных
  const login = ref($cookies.get("login"))
  const progress = ref($cookies.get("progress").progress4)
  const difficult = ref(useRoute().params.difficult)
  const maxProgress = difficult.value === "easy" ? 2 : 3

  const hasCompleted = ref(false)
  const hasHint = ref(false)

  // Логика перехода
  const stage = ref(progress.value)
  if (stage.value >= maxProgress) {
    stage.value = maxProgress - 1;
  }
  watch(stage, () => {
    if (stage.value < 0) {
      stage.value = 0
    }
    if (stage.value < progress.value) {
      hasCompleted.value = true
    } else if (stage.value > progress.value) {
      UsersDatabase.updateProgress(login.value, "progress4")
      progress.value++;
      const newProgress = $cookies.get("progress")
      newProgress.progress4 = progress
      $cookies.set("progress", newProgress)
    }
  })

  const router = useRouter()
  function go() {
    hasCompleted.value = false
    stage.value++;
    if (stage.value === maxProgress) {
      router.replace("/main")
    }
  }

  // Вспомогательная часть

  const substage1 = ref(0) // Этап 1

  const telephonNumber = ref("")
  const isCorrectTelephon = ref(false)
  // Проверка и дополнение номера телефона
  function checkTelephonNumber() {
    if (telephonNumber.value.length <= 1) {
      telephonNumber.value = "+7" + telephonNumber.value
    }
    var allowedChars = true
    for (let i = 0; i < telephonNumber.value.length; i++) {
      if (!telephonNumber.value[i].match(/[0-9]/) && telephonNumber.value[i] !== '+') {
        allowedChars = false
      }
    }
    if (telephonNumber.value.length === 12 && allowedChars) {
      telephonNumber.value = "+7 (" + telephonNumber.value[2] + telephonNumber.value[3] + telephonNumber.value[4] + ") " + telephonNumber.value[5] + telephonNumber.value[6] + telephonNumber.value[7] + "-" + telephonNumber.value[8] + telephonNumber.value[9] + "-" + telephonNumber.value[10] + telephonNumber.value[11]
    }
    isCorrectTelephon.value = /[+][0-9] [(][0-9][0-9][0-9][)] [0-9][0-9][0-9][-][0-9][0-9][-][0-9][0-9]/.test(telephonNumber.value) && telephonNumber.value.length === 18
  }
  watch(telephonNumber, checkTelephonNumber)

  const mailAdress = ref("")
  const password = ref("")
  const passwordRepeat = ref("")

  const oms = ref("")
  const isCorrectOms = ref(false)
  // Проверка контрольной суммы по https://rostov-tfoms.ru/services/zasedaniya-rabochih-grupp/erp/enp-struct
  function checkOms() {
    if (oms.value.length !== 16) {
      isCorrectOms.value = false
    } else {
      var controlSum = 0
      for (let i = 0; i < 15; i += 2) {
        controlSum *= parseInt(oms.value[i])
      }
      controlSum = controlSum.toString
      for (let i = 1; i < 15; i += 2) {
        controlSum = oms.value[i] + controlSum
      }
      isCorrectOms.value = parseInt(controlSum) % 10 == oms.value[15]
    }
  }
  watch(oms, checkOms)

  const doctor = ref("")
  const clinic = ref("")
  const date = ref("")
  const time = ref("")

  const substage2 = ref(0) // Этап 2
</script>

<template>
  <Header />
  <main class="lesson">
    <div id="info-block">
      <svg width="500" height="100" class="lesson-background">
        <image href="./images/Lesson4.png"></image>
      </svg>
      <h1 class="title" style="padding-top: 20px;">Госуслуги</h1>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===0">Регистрация в Госуслугах</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===1">Запишись ко врачу</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===2">Получение электронного удостоверения пенсионера</h2>
      <div class="info">
        <div class="info-part" v-if="stage===0">
          <p>Госуслуги - онлайн-сервис, предоставляющий доступ к государственным услугам.</p>
          <p>Здесь можно, например, получить доступ к медицинской карте или школьному электронному дневнику.</p>
          <p>Но сначала надо зарегистрироваться:</p>
          <ol>
            <li style="font-size: large;">Зайдите в Госуслуги.</li>
            <li style="font-size: large;">Введите номер телефона, почту, СНИЛС (ненастоящие, конечно).</li>
            <li style="font-size: large;">Придумайте и повторите пароль.</li>
          </ol>
          <p class="task">Зарегистрируйтесь в Госуслугах.</p>
        </div>
        <div class="info-part" v-if="stage===1">
          <p>Через Госуслуги можно дистанционно записаться ко врачу.</p>
          <p>Чтобы записаться:</p>
          <ol>
            <li style="font-size: large;">Введите 16-значный номер полиса ОМС.</li>
            <li style="font-size: large;">Выберете специальность врача.</li>
            <li style="font-size: large;">Выберете поликлинику.</li>
            <li style="font-size: large;">Выберете дату и время приёма.</li>
            <li style="font-size: large;">Подтвердите запись.</li>
          </ol>
          <p class="task">Запишитесь ко врачу.</p>
        </div>
        <div class="info-part" v-if="stage===2">
          <p>Через Госуслуги можно получить электронное пенсионное удостоверение.</p>
          <p>Электронное удостоверение пенсионера - официальное подтверждение статуса пенсионера.</p>
          <p>Чтобы получить:</p>
          <ol>
            <li style="font-size: large;">Нажмите на кнопку "Запросить" этого документа.</li>
            <li style="font-size: large;">Затем согласитесь на использование персональных данных.</li>
          </ol>
          <p class="task">Получите электронное удостоверение пенсионера.</p>
        </div>
      </div>
      <button id="help-button" @click="hasHint=!hasHint">Помощь</button>
      <button id="back-button" @click="stage--">Назад</button>
      <button id="go-button" @click="go" :disabled="!hasCompleted">Вперёд</button>
      <button id="menu-button" @click="router.replace('/main')">В меню</button>
    </div>
    <div id="interactive-block">
      <svg width="360" height="700" class="lesson-image">
        <image href="./images/Lesson 4.1.png" v-if="stage===0&&substage1===0" />
        <image href="./images/Lesson 4.1a.png" v-else />
      </svg>
      <div v-if="stage===0">
        <button @click="substage1++" v-if="substage1===0" style="position: absolute; width: 70px; height: 70px; margin: 492px 0 0 27px;" class="hint" :class="{ invisible: !hasHint }" />
        <div v-if="substage1===1">
          <p style="position: absolute; color: black; font-size: x-large; margin: 150px 0 0 35px;">Введите номер телефона</p>
          <input v-model="telephonNumber" style="position: absolute; width: 290px; height: 50px; margin: 200px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!isCorrectTelephon ? 'red' : 'white' }" placeholder="+7 (XXX) XXX-XX-XX">
          <p style="position: absolute; color: black; font-size: large; margin: 250px 0 0 50px; width: 250px; text-align: center;" :style="{ color: isCorrectTelephon ? 'green' : 'red' }">Номер телефона в формате +7 (XXX) XXX-XX-XX</p>
          <p style="position: absolute; color: black; font-size: x-large; margin: 320px 0 0 55px;">Введите адрес почты</p>
          <input v-model="mailAdress" style="position: absolute; width: 290px; height: 50px; margin: 370px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!mailAdress ? 'red' : 'white' }" placeholder="Адрес почты">
          <p style="position: absolute; color: black; font-size: x-large; margin: 440px 0 0 80px;">Введите пароль</p>
          <input type="password" v-model="password" style="position: absolute; width: 290px; height: 50px; margin: 490px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!password ? 'red' : 'white' }" placeholder="Пароль">
          <input type="password" v-model="passwordRepeat" style="position: absolute; width: 290px; height: 50px; margin: 540px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&(password!==passwordRepeat||!password) ? 'red' : 'white' }" placeholder="Повторите пароль">
          <button @click="hasCompleted=isCorrectTelephon&&mailAdress&&password===passwordRepeat&&password" style="position: absolute; margin: 610px 0 0 50px; padding: 10px; font-size: x-large; color: black;" :style="{ background: hasHint ? 'red' : 'orange', 'font-weight': isCorrectTelephon&&mailAdress&&password===passwordRepeat&&password ? 'bold' : 'normal' }">Зарегистрироваться</button>
        </div>
      </div>
      <div v-if="stage===1">
        <p style="position: absolute; color: black; font-size: x-large; margin: 150px 0 0 45px;">Введите номер полиса</p>
        <input v-model="oms" style="position: absolute; width: 290px; height: 50px; margin: 200px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!isCorrectOms ? 'red' : 'white' }" placeholder="Номер полиса">
        <p style="position: absolute; color: black; font-size: large; margin: 250px 0 0 50px; width: 250px; text-align: center;" :style="{ color: isCorrectOms ? 'green' : 'red' }">Должна совпадать контрольная сумма</p>
        <p v-if="isCorrectOms" style="position: absolute; color: black; font-size: x-large; margin: 320px 0 0 50px;">Выберете специалиста</p>
        <select v-if="isCorrectOms" v-model="doctor" style="position: absolute; width: 290px; height: 50px; margin: 370px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!doctor ? 'red' : 'white' }">
          <option value="" />
          <option value="a">Педиатр</option>
          <option value="b">Врач участковый</option>
          <option value="c">Врач ОРВИ</option>
          <option value="d">Кардиолог</option>
          <option value="e">Гастроэнтеролог</option>
        </select>
        <p v-if="isCorrectOms&&doctor" style="position: absolute; color: black; font-size: x-large; margin: 440px 0 0 45px;">Выберете поликлинику</p>
        <select v-if="isCorrectOms&&doctor" v-model="clinic" style="position: absolute; width: 290px; height: 50px; margin: 490px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!clinic ? 'red' : 'white' }">
          <option value="" />
          <option value="a">Поликлиника № 1 (Центральная, 5)</option>
          <option value="b">Поликлиника № 2 (Красная, 17к2)</option>
          <option value="c">Поликлиника № 3 (Валовая, 3)</option>
          <option value="d">Поликлиника № 4 (Калининградская, 18)</option>
          <option value="e">Поликлиника № 5 (Зелёная, 1стр17)</option>
        </select>
        <input v-if="isCorrectOms&&doctor&&clinic" v-model="date" type="date" style="position: absolute; width: 180px; height: 50px; margin: 570px 0 0 30px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!date ? 'red' : 'white' }">
        <input v-if="isCorrectOms&&doctor&&clinic" v-model="time" type="time" style="position: absolute; width: 105px; height: 50px; margin: 570px 0 0 210px; font-size: x-large; text-align: center;" :style="{ background: hasHint&&!time ? 'red' : 'white' }">
        <button @click="hasCompleted=true" v-if="isCorrectOms&&doctor&&clinic&&date&&time" style="position: absolute; width: 250px; height: 50px; margin: 620px 0 0 50px; font-size: x-large; font-weight: bolder; text-align: center; color: black;" :style="{ background: hasHint ? 'red' : 'orange' }">Записаться</button>
      </div>
      <div v-if="stage===2">
        <span v-if="substage2===0" style="position: absolute; width: 290px; height: 220px; color: black; background-color: bisque; margin: 150px 0 0 30px; border-radius: 10px;" class="hover">
          <p style="font-size: x-large; font-weight: bolder;">Электронная трудовая книжка</p>
          <p style="font-size: larger;">Закажите выписку из трудовой книги для проверки трудового стажа и мест работ</p>
          <button style="padding: 5px; font-size: x-large; color: white; background-color: blue; margin-left: 10px;">Заказать выписку</button>
        </span>
        <span v-if="substage2===0" style="position: absolute; width: 290px; height: 260px; color: black; background-color: bisque; margin: 400px 0 0 30px; border-radius: 10px;" class="hover">
          <p style="font-size: x-large; font-weight: bolder;">Электронное свидетельство пенсионера</p>
          <p style="font-size: larger;">Запросите электронное свидетельство для получения социальных льгот</p>
          <button @click="substage2++" style="padding: 5px; font-size: x-large; color: white; margin-left: 10px;" :style="{ background: hasHint ? 'red' : 'blue' }">Запросить</button>
        </span>
        <div v-if="substage2===1" style="position: absolute; color: black; text-align: center;">
          <p style="font-size: x-large; font-weight: bolder; margin: 150px 0 0 25px; width: 300px;">Согласие на обработку персональнях данных</p>
          <p style="font-size: larger; margin: 30px 0 0 35px; width: 280px;">Госуслуги запрашивает ваше согласие, чтобы отправить запросы в ведомства и организации на получение, хранение и обновление ваших данных в личном кабинете</p>
          <button @click="hasCompleted=true" style="margin-top: 30px; font-size: x-large; font-weight: bolder; color: white; padding: 10px;" :style="{ 'background-color': hasHint ? 'red' : 'blue' }">Разрешить</button>
        </div>
      </div>
    </div>
  </main>
</template>
