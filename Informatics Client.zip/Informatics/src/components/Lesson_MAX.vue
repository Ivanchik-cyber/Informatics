<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  // Импорт
  import {ref, watch} from "vue"
  import VueCookies from "vue-cookies"
  import {useRoute, useRouter} from "vue-router"
  import UsersDatabase from "./services/UsersDatabase"
  import Header from "./elements/Header_Element.vue"
  import UserIcon from "./elements/User_Icon.vue"

  // Получение метаданных
  const login = ref($cookies.get("login"))
  const progress = ref($cookies.get("progress").progress2)
  const difficult = ref(useRoute().params.difficult)
  const maxProgress = difficult.value === "easy" ? 3 : 5

  const hasCompleted = ref(false)
  const hasHint = ref(false)

  // Логика перехода
  const stage = ref(progress.value)
  if (stage.value >= maxProgress) {
    stage.value = maxProgress - 1;
  }
  watch(stage, () => {
    if (stage.value < 0) {
      stage.value = 0
    }
    if (stage.value < progress.value) {
      hasCompleted.value = true
    } else if (stage.value > progress.value) {
      UsersDatabase.updateProgress(login.value, "progress2")
      progress.value++;
      const newProgress = $cookies.get("progress")
      newProgress.progress2 = progress
      $cookies.set("progress", newProgress)
    }
  })

  const router = useRouter()
  function go() {
    hasCompleted.value = false
    stage.value++;
    if (stage.value === maxProgress) {
      router.replace("/main")
    }
  }

  // Вспомогательная часть

  const substage1 = ref(0) // Этап 1

  const textmsg = ref("")

  const firstImageSelect = ref(false)
  const secondImageSelect = ref(false)
  const thirdImageSelect = ref(false)
  const fourthImageSelect = ref(false)

  const substage3 = ref(0) // Этап 3

  const substage4 = ref(0) // Этап 4

  const firstUserSelect = ref(false)
  const secondUserSelect = ref(false)
  const thirdUserSelect = ref(false)
  const fourthUserSelect = ref(false)
  const fifthUserSelect = ref(false)

  const groupName = ref("")
  const groupBg = ref("")
  const groupMain = ref("")

  const emojiTextmsg = ref("")
  const hasEmoji = ref(false)
</script>

<template>
  <Header />
  <main class="lesson">
    <div id="info-block">
      <svg width="500" height="100" class="lesson-background">
        <image href="./images/Lesson2.png"></image>
      </svg>
      <h1 class="title" style="padding-top: 20px;">Работа с мессенджером MAX</h1>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===0">Отправка текстового сообщения</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===1">Отправка изображений</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===2">Создание нового чата</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===3">Создание нового группового чата</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===4">Отправка эмодзи</h2>
      <div class="info">
        <div class="info-part" v-if="stage===0">
          <p>Для дистанционного общения можно использовать мессенджер.</p>
          <p>Мессенджер - программа для мгновенного обмена текстовыми сообщениями, фотографиями, аудиофайлами и другой иформацией.</p>
          <p>Для начала общения:</p>
          <ol>
            <li style="font-size: large">Зайдите в MAX.</li>
            <li style="font-size: large">Выберете контакт "Друг".</li>
            <li style="font-size: large">Напишите любое сообщение.</li>
            <li style="font-size: large">Отправьте сообщение.</li>
          </ol>
          <p class="task">Отправьте текстовое сообщение.</p>
        </div>
        <div class="info-part" v-if="stage===1">
          <p>Иногда недостаточно только текстовых сообщений.</p>
          <p>К сообщений можно прикрепить изображения!</p>
          <p>Выберете хотя бы одно изображение.</p>
          <p>Затем нажмите на кнопку "Отправить".</p>
          <p class="task">Отправьте изображение.</p>
        </div>
        <div class="info-part" v-if="stage===2">
          <p>В мессенджерах прежде чем начать общение с кем-то, надо создать чат с ним.</p>
          <p>Чтобы создать новый чат:</p>
          <ol>
            <li style="font-size: large;">Нажмите на кнопку с плюсом.</li>
            <li style="font-size: large;">Затем выберете контакт "Дима".</li>
            <li style="font-size: large;">Напишите ему какое-то приветственное сообщение.</li>
          </ol>
          <p class="task">Создайте новый контакт.</p>
        </div>
        <div class="info-part" v-if="stage===3">
          <p>Кроме чата с одним человеком можно создать группу.</p>
          <p>В группе сообщения отправляются всем участникам группы, и каждый может на него ответить.</p>
          <p>Чтобы создать группу:</p>
          <ol>
            <li style="font-size: large;">Нажмите на кнопку с плюсом.</li>
            <li style="font-size: large;">Затем выберете как минимум 3 контакта.</li>
            <li style="font-size: large;">Настройте группу.</li>
            <li style="font-size: large;">Напишите в группу какое-то приветственное сообщение.</li>
          </ol>
          <p class="task">Создайте новую группу.</p>
        </div>
        <div class="info-part" v-if="stage===4">
          <p>В тексте бывает трудно выразить какие-либо эмоции.</p>
          <p>Поэтому придумали эмодзи - небольшие картинки в тексте.</p>
          <p>Чтобы отправить эмодзи нажмите на кнопки нижней панели</p>
          <p class="task">Отправьте сообщение с эмодзи.</p>
        </div>
      </div>
      <button id="help-button" @click="hasHint=!hasHint">Помощь</button>
      <button id="back-button" @click="stage--">Назад</button>
      <button id="go-button" @click="go" :disabled="!hasCompleted">Вперёд</button>
      <button id="menu-button" @click="router.replace('/main')">В меню</button>
    </div>
    <div id="interactive-block">
      <svg width="360" height="700" class="lesson-image">
        <image href="./images/Lesson 2.1.png" v-if="stage===0&&substage1===0" />
        <image href="./images/Lesson 2.1a.png" v-if="stage===0&&(substage1===1||substage1===2)" />
        <image href="./images/Lesson 2.2.png" v-if="stage===1" />
        <image href="./images/Lesson 2.3.png" v-if="stage===2" />
        <image href="./images/Lesson 2.4.png" v-if="stage===3" />
        <image href="./images/Lesson 2.5.png" v-if="stage===4" />
      </svg>
      <div v-if="stage===0">
        <button v-if="substage1===0" @click="substage1++" style="position: absolute; width: 70px; height: 70px; margin: 407px 0 0 102px;" class="hint" :class="{ invisible: !hasHint }" />
        <div v-if="substage1===1">
          <UserIcon @click="substage1++" :background="hasHint ? 'red' : 'mediumblue'" userBackground="green" userName="Друг" userPs="Привет! Как дела?" style="margin: 150px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="violet" userName="Мама" userPs="Ты уроки сделал?" style="margin: 250px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="brown" userName="Учительница" userPs="Сегодня 6 уроков." style="margin: 350px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="chocolate" userName="Одноклассник" userPs="Скинешь дз?" style="margin: 450px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="grey" userName="Незнакомец" userPs="Вы выиграли лотерею!" style="margin: 550px 0 0 25px;" />
        </div>
        <div v-if="substage1===2">
          <UserIcon background="mediumblue" userBackground="green" userName="Друг" userPs="В сети" style="margin: 140px 0 0 25px;" />
          <span style="position: absolute; margin: 250px 0 0 25px; width: 150px; height: 50px; background: royalblue; border-radius: 10px;">
            <p style="margin-top: 10px; color: lightgray;">Как дела?</p>
          </span>
          <input v-model="textmsg" style="position: absolute; width: 200px; height: 40px; margin: 630px 0 0 25px; text-align: center; font-size: large;" placeholder="Введите сообщение">
          <button @click="hasCompleted=textmsg" style="position: absolute; width: 90px; height: 40px; margin: 630px 0 0 230px;" :style="{ 'background-color': hasHint ? 'red' : textmsg ? 'dodgerblue' : 'lightblue' }">Отправить</button>
        </div>
      </div>
      <div v-if="stage===1">
        <svg class="hover" width="130px" height="130px" style="position: absolute; border-radius: 15px; opacity: 0.8; margin: 180px 0 0 35px;">
          <image href="./images/Lesson1.png" />
        </svg>
        <svg class="hover" width="130px" height="130px" style="position: absolute; border-radius: 15px; opacity: 0.8; margin: 180px 0 0 190px;">
          <image href="./images/Lesson2.png" />
        </svg>
        <svg class="hover" width="130px" height="130px" style="position: absolute; border-radius: 15px; opacity: 0.8; margin: 350px 0 0 35px;">
          <image href="./images/Lesson3.png" />
        </svg>
        <svg class="hover" width="130px" height="130px" style="position: absolute; border-radius: 15px; opacity: 0.8; margin: 350px 0 0 190px;">
          <image href="./images/Lesson4.png" />
        </svg>
        <input v-model="firstImageSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 190px 0 0 45px;">
        <input v-model="secondImageSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 190px 0 0 200px;">
        <input v-model="thirdImageSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 360px 0 0 45px;">
        <input v-model="fourthImageSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 360px 0 0 200px;">
        <button @click="hasCompleted=firstImageSelect|secondImageSelect|thirdImageSelect|fourthImageSelect"
        :style="{ 'background-color': hasHint ? 'red' : 'chocolate', 'font-weight': firstImageSelect|secondImageSelect|thirdImageSelect|fourthImageSelect ? 'bold' : 'normal' }"
        style="position: absolute; font-size: x-large; width: 150px; height: 50px; margin: 550px 0 0 100px;">Отправить</button>
      </div>
      <div v-if="stage===2">
        <div v-if="substage3===0">
          <UserIcon background="mediumblue" userBackground="green" userName="Друг" userPs="Привет! Как дела?" style="margin: 150px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="violet" userName="Мама" userPs="Ты уроки сделал?" style="margin: 250px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="brown" userName="Учительница" userPs="Сегодня 6 уроков." style="margin: 350px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="chocolate" userName="Одноклассник" userPs="Скинешь дз?" style="margin: 450px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="grey" userName="Незнакомец" userPs="Вы выиграли лотерею!" style="margin: 550px 0 0 25px;" />
          <button @click="substage3++" :style="{ 'background-color': hasHint ? 'red' : 'midnightblue' }" style="position: absolute; font-size: xx-large; width: 55px; height: 55px; color: white; border-radius: 100%; margin: 610px 0 0 260px">+</button>
        </div>
        <div v-if="substage3===1">
          <UserIcon background="grey" userBackground="black" userName="Алина" userPs="Ничего нету..." style="margin: 150px 0 0 25px;" />
          <UserIcon @click="substage3++" :background="hasHint ? 'red' : 'grey'" userBackground="black" userName="Дима" userPs="Ничего нету..." style="margin: 250px 0 0 25px;" />
          <UserIcon background="grey" userBackground="black" userName="Катя" userPs="Ничего нету..." style="margin: 350px 0 0 25px;" />
          <UserIcon background="grey" userBackground="black" userName="Егор" userPs="Ничего нету..." style="margin: 450px 0 0 25px;" />
          <UserIcon background="grey" userBackground="black" userName="Рома" userPs="Ничего нету..." style="margin: 550px 0 0 25px;" />
        </div>
        <div v-if="substage3===2">
          <UserIcon background="grey" userBackground="black" userName="Дима" userPs="Не в сети" style="margin: 140px 0 0 25px;" />
          <input v-model="textmsg" style="position: absolute; width: 200px; height: 40px; margin: 630px 0 0 25px; text-align: center; font-size: large;" placeholder="Введите сообщение">
          <button @click="hasCompleted=textmsg" style="position: absolute; width: 90px; height: 40px; margin: 630px 0 0 230px;" :style="{ 'background-color': hasHint ? 'red' : textmsg ? 'dodgerblue' : 'lightblue' }">Отправить</button>
        </div>
      </div>
      <div v-if="stage===3">
        <div v-if="substage4===0">
          <UserIcon background="mediumblue" userBackground="green" userName="Друг" userPs="Привет! Как дела?" style="margin: 150px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="violet" userName="Мама" userPs="Ты уроки сделал?" style="margin: 250px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="brown" userName="Учительница" userPs="Сегодня 6 уроков." style="margin: 350px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="chocolate" userName="Одноклассник" userPs="Скинешь дз?" style="margin: 450px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="grey" userName="Незнакомец" userPs="Вы выиграли лотерею!" style="margin: 550px 0 0 25px;" />
          <button @click="substage4++" :style="{ 'background-color': hasHint ? 'red' : 'midnightblue' }" style="position: absolute; font-size: xx-large; width: 55px; height: 55px; color: white; border-radius: 100%; margin: 610px 0 0 260px">+</button>
        </div>
        <div v-if="substage4===1">
          <UserIcon background="mediumblue" userBackground="green" userName="Друг" userPs="Привет! Как дела?" style="margin: 150px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="violet" userName="Мама" userPs="Ты уроки сделал?" style="margin: 250px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="brown" userName="Учительница" userPs="Сегодня 6 уроков." style="margin: 350px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="chocolate" userName="Одноклассник" userPs="Скинешь дз?" style="margin: 450px 0 0 25px;" />
          <UserIcon background="mediumblue" userBackground="grey" userName="Незнакомец" userPs="Вы выиграли лотерею!" style="margin: 550px 0 0 25px;" />
          <input v-model="firstUserSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 160px 0 0 280px;">
          <input v-model="secondUserSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 260px 0 0 280px;">
          <input v-model="thirdUserSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 360px 0 0 280px;">
          <input v-model="fourthUserSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 460px 0 0 280px;">
          <input v-model="fifthUserSelect" type="checkbox" style="position: absolute; width: 30px; height: 30px; margin: 560px 0 0 280px;">
          <button @click="substage4+=firstUserSelect+secondUserSelect+thirdUserSelect+fourthUserSelect+fifthUserSelect>=3"
          :style="{ 'background-color': hasHint ? 'red' : 'chocolate', 'font-weight': firstUserSelect+secondUserSelect+thirdUserSelect+fourthUserSelect+fifthUserSelect>=3 ? 'bold' : 'normal' }"
          style="position: absolute; font-size: x-large; width: 150px; height: 50px; margin: 600px 0 0 100px;">Создать</button>
        </div>
        <div v-if="substage4===2">
          <div style="position: absolute; margin: 140px 0 0 65px; color: black; font-size: x-large; font-weight: bold;">Создание группы</div>
          <div style="position: absolute; margin: 200px 0 0 55px; color: black; font-size: larger;">Напишите название группы</div>
          <input v-model="groupName" style="position: absolute; margin: 250px 0 0 50px; width: 240px; height: 30px; text-align: center;" placeholder="Название группы">
          <div style="position: absolute; margin: 300px 0 0 55px; color: black; font-size: larger;">Выберете цвет фона группы</div>
          <button @click="groupBg='yellow'" style="position: absolute; width: 60px; height: 70px; background-color: yellow; margin: 350px 0 0 30px;" />
          <button @click="groupBg='green'" style="position: absolute; width: 60px; height: 70px; background-color: green; margin: 350px 0 0 105px;" />
          <button @click="groupBg='red'" style="position: absolute; width: 60px; height: 70px; background-color: red; margin: 350px 0 0 180px;" />
          <button @click="groupBg='blue'" style="position: absolute; width: 60px; height: 70px; background-color: blue; margin: 350px 0 0 255px;" />
          <div style="position: absolute; margin: 450px 0 0 50px; color: black; font-size: larger;">Выберете цвет иконки группы</div>
          <button @click="groupMain='violet'" style="position: absolute; width: 60px; height: 70px; background-color: violet; margin: 500px 0 0 30px;" />
          <button @click="groupMain='cyan'" style="position: absolute; width: 60px; height: 70px; background-color: cyan; margin: 500px 0 0 105px;" />
          <button @click="groupMain='orange'" style="position: absolute; width: 60px; height: 70px; background-color: orange; margin: 500px 0 0 180px;" />
          <button @click="groupMain='gray'" style="position: absolute; width: 60px; height: 70px; background-color: gray; margin: 500px 0 0 255px;" />
          <button @click="substage4+=groupName.length>0&&groupBg.length>0&&groupMain.length>0"
          :style="{ 'background-color': hasHint ? 'red' : 'chocolate', 'font-weight': groupName.length>0&&groupBg.length>0&&groupMain.length>0 ? 'bold' : 'normal' }"
          style="position: absolute; font-size: x-large; width: 150px; height: 50px; margin: 600px 0 0 100px;">Создать</button>
        </div>
        <div v-if="substage4===3">
          <UserIcon :background="groupBg" :userBackground="groupMain" :userName="groupName" userPs="В сети 1 участник" style="margin: 140px 0 0 25px;" />
          <input v-model="textmsg" style="position: absolute; width: 200px; height: 40px; margin: 630px 0 0 25px; text-align: center; font-size: large;" placeholder="Введите сообщение">
          <button @click="hasCompleted=textmsg" style="position: absolute; width: 90px; height: 40px; margin: 630px 0 0 230px;" :style="{ 'background-color': hasHint ? 'red' : textmsg ? 'dodgerblue' : 'lightblue' }">Отправить</button>
        </div>
      </div>
      <div v-if="stage==4">
        <UserIcon :background="groupBg||'blue'" :userBackground="groupMain||'grey'" :userName="groupName||'Группа'" userPs="В сети 1 участник" style="margin: 140px 0 0 25px;" />
        <input v-model="emojiTextmsg" style="position: absolute; width: 200px; height: 40px; margin: 600px 0 0 25px; text-align: center; font-size: large;" placeholder="Введите сообщение">
        <button @click="hasCompleted=hasEmoji" style="position: absolute; width: 90px; height: 40px; margin: 600px 0 0 230px;" :style="{ 'background-color': hasHint ? 'red' : hasEmoji ? 'dodgerblue' : 'lightblue' }">Отправить</button>
        <button @click="emojiTextmsg+='😀';hasEmoji=true" style="position: absolute; width: 70px; height: 40px; margin: 640px 0 0 27px; background-color: azure; color: white; font-size: larger;">😀</button>
        <button @click="emojiTextmsg+='😄';hasEmoji=true" style="position: absolute; width: 70px; height: 40px; margin: 640px 0 0 101px; background-color: azure; color: white; font-size: larger;">😄</button>
        <button @click="emojiTextmsg+='😯';hasEmoji=true" style="position: absolute; width: 70px; height: 40px; margin: 640px 0 0 175px; background-color: azure; color: white; font-size: larger;">😯</button>
        <button @click="emojiTextmsg+='😟';hasEmoji=true" style="position: absolute; width: 70px; height: 40px; margin: 640px 0 0 250px; background-color: azure; color: white; font-size: larger;">😟</button>
      </div>
    </div>
  </main>
</template>
