<!-- eslint-disable no-undef -->
<!-- eslint-disable no-unused-vars -->
<script setup>
  // Импорт
  import {ref, watch} from "vue"
  import VueCookies from "vue-cookies"
  import {useRoute, useRouter} from "vue-router"
  import UsersDatabase from "./services/UsersDatabase"
  import Header from "./elements/Header_Element.vue"

  // Получение метаданных
  const login = ref($cookies.get("login"))
  const progress = ref($cookies.get("progress").progress1)
  const difficult = ref(useRoute().params.difficult)
  const maxProgress = difficult.value === "easy" ? 2 : 4

  const hasCompleted = ref(false)
  const hasHint = ref(false)

  // Логика перехода
  const stage = ref(progress.value)
  if (stage.value >= maxProgress) {
    stage.value = maxProgress - 1;
  }
  watch(stage, () => {
    if (stage.value < 0) {
      stage.value = 0
    }
    if (stage.value < progress.value) {
      hasCompleted.value = true
    } else if (stage.value > progress.value) {
      UsersDatabase.updateProgress(login.value, "progress1")
      progress.value++;
      const newProgress = $cookies.get("progress")
      newProgress.progress1 = progress
      $cookies.set("progress", newProgress)
    }
  })

  const router = useRouter()
  function go() {
    hasCompleted.value = false
    stage.value++;
    if (stage.value === maxProgress) {
      router.replace("/main")
    }
  }

  // Вспомогательная часть

  function swapImages() { // Этап 1
    const image = document.querySelector(".lesson-image").firstChild
    if (image.href.baseVal === "/src/components/images/Lesson 1.1a.png") {
      image.setAttribute("href", "/src/components/images/Lesson 1.1.png")
      hasCompleted.value = true
    } else {
      image.setAttribute("href", "/src/components/images/Lesson 1.1a.png")
    }
  }

  const volumeValue = ref(0) // Этап 2
  const volume = ref(`0%`)
  const volumeCircle = ref(`70px`)
  watch(volumeValue, () => {
    volumeValue.value = Math.min(volumeValue.value, 100)
    volumeValue.value = Math.max(volumeValue.value, 0)
    volume.value = ref(`${volumeValue.value}%`)
    volumeCircle.value = ref(`${230 * volumeValue.value / 100 + 70}px`)
    hasCompleted.value = true
  })

  const substage3 = ref(0) // Этап 3

  const wifiPassword = ref("")
  const rightWifiPassword = ref("8dk9sspc4")

  const substage4 = ref(0) // Этап 4

  const appName = ref("")
  const rightAppName = ref("max")
</script>

<template>
  <Header />
  <main class="lesson">
    <div id="info-block">
      <svg width="500" height="100" class="lesson-background">
        <image href="./images/Lesson1.png"></image>
      </svg>
      <h1 class="title" style="padding-top: 20px;">Основы смартфона</h1>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===0">Включение и выключение телефона</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===1">Регулировка громкости</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===2">Подключение к Wi-Fi (Вай-Фай)</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===3">Установка приложений</h2>
      <div class="info">
        <div class="info-part" v-if="stage===0">
          <p>Прежде чем пользоваться телефоном, нужно его включить.</p>
          <p>После включения вы попадёте на экран блокировки, где находятся текущее время, дата, уведомления и другая информация.</p>
          <p>Затем, нужно ввести пароль, пин-код или фейс-айди (проверка лица), если они у вас установлены.</p>
          <p>Однако, его нельзя постоянно держать включённым, так как он будет быстрее разряжаться.</p>
          <p>Выключение завершит все активные процессы, фоновые же продолжатся.</p>
          <p class="task">Включите и выключите телефон, нажав на маленькую боковую кнопку.</p>
        </div>
        <div class="info-part" v-if="stage===1">
          <p>При помощи телефона можно слушать музыку или смотреть видео.</p>
          <p>Поэтому вы можете регулировать громкость с помощью большой боковой кнопки.</p>
          <p>Для увеличения нажмите на верхнюю часть, для уменьшения - на нижнюю.</p>
          <p class="task">Отрегулируйте громкость.</p>
        </div>
        <div class="info-part" v-if="stage===2">
          <p>Wi-Fi - это технология беспроводной передачи данных.</p>
          <p>Например, Wi-Fi используют вместо интернета или для подключения какого-то устройства.</p>
          <p>Для подключения к Wi-Fi:</p>
          <ol>
            <li style="font-size: large">Зайдите в настройки.</li>
            <li style="font-size: large">Выберете раздел Wi-Fi.</li>
            <li style="font-size: large">Выберете сеть "Сеть 3".</li>
            <li style="font-size: large">Введите пароль "8dk9sspc4" (без кавычек).</li>
            <li style="font-size: large">Нажмите на кнопку "Подключиться".</li>
          </ol>
          <p class="task">Подключитесь к Wi-Fi.</p>
        </div>
        <div class="info-part" v-if="stage===3">
          <p>Помимо изначальных приложений можно установить дополнительные.</p>
          <p>Для этого воспользуемся площадкой RuStore (РуСтор).</p>
          <p>Давайте установим мессенджер MAX, который нам пригодится в следующем уроке:</p>
          <ol>
            <li style="font-size: large">Зайдите в RuStore.</li>
            <li style="font-size: large">Введите в поисковую строку "MAX" и нажмите кнопку поиска.</li>
            <li style="font-size: large">Найдите MAX среди результатов.</li>
            <li style="font-size: large">Нажмите кнопку "Установить"</li>
          </ol>
          <p class="task">Установите приложение.</p>
        </div>
      </div>
      <button id="help-button" @click="hasHint=!hasHint">Помощь</button>
      <button id="back-button" @click="stage--">Назад</button>
      <button id="go-button" @click="go" :disabled="!hasCompleted">Вперёд</button>
      <button id="menu-button" @click="router.replace('/main')">В меню</button>
    </div>
    <div id="interactive-block">
      <svg width="360" height="700" class="lesson-image">
        <image href="./images/Lesson 1.1.png" v-if="stage===0" />
        <image href="./images/Lesson 1.2.png" v-if="stage===1" />
        <image href="./images/Lesson 1.3.png" v-if="stage===2&&substage3===0" />
        <image href="./images/Lesson 1.3a.png" v-if="stage===2&&substage3===1" />
        <image href="./images/Lesson 1.3b.png" v-if="stage===2&&substage3===2" />
        <image href="./images/Lesson 1.3c.png" v-if="stage===2&&substage3===3" />
        <image href="./images/Lesson 1.4.png" v-if="stage===3&&substage4===0" />
        <image href="./images/Lesson 1.4a.png" v-if="stage===3&&substage4===1" />
        <image href="./images/Lesson 1.4b.png" v-if="stage===3&&substage4===2" />
        <image href="./images/Lesson 1.4c.png" v-if="stage===3&&substage4===3" />
      </svg>
      <div v-if="stage===0">
        <button @click="swapImages" style="position: absolute; margin: 240px 0 0 340px; width: 20px; height: 70px;" class="hint" :class="{ invisible: !hasHint }" />
      </div>
      <div v-if="stage===1">
        <div style="width: 230px; height: 10px; background: lightgrey; position: absolute; margin: 95px 0 0 80px; border-radius: 10px; overflow: hidden;">
          <div style="height: 10px; background: dodgerblue; position: absolute;" :style="{ width: volume.value }" />
        </div>
        <div style="width: 20px; height: 20px; background: royalblue; position: absolute; margin: 90px 0 0 70px; border-radius: 100%;" :style="{ 'margin-left': volumeCircle.value || '70px' }"/>
        <button @click="volumeValue+=5" style="width: 20px; height: 50px; position: absolute; margin: 85px 0 0 340px;" class="hint" :class="{ invisible: !hasHint }" />
        <button @click="volumeValue-=5" style="width: 20px; height: 50px; position: absolute; margin: 140px 0 0 340px;" class="hint" :class="{ invisible: !hasHint }" />
      </div>
      <div v-if="stage===2">
        <button v-if="substage3===0" @click="substage3++" style="width: 70px; height: 70px; position: absolute; margin: 407px 0 0 27px;" class="hint" :class="{ invisible: !hasHint }" />
        <button v-if="substage3===1" @click="substage3++" style="width: 280px; height: 80px; position: absolute; margin: 210px 0 0 40px;" class="hint" :class="{ invisible: !hasHint }" />
        <button v-if="substage3===2" @click="substage3++" style="width: 280px; height: 50px; position: absolute; margin: 580px 0 0 40px;" class="hint" :class="{ invisible: !hasHint }" />
        <input v-if="substage3===3" v-model="wifiPassword" style="width: 200px; height: 30px; position: absolute; margin: 340px 0 0 70px;" placeholder="Ваш пароль">
        <button @click="hasCompleted=wifiPassword===rightWifiPassword" v-if="substage3===3" style="width: 200px; height: 40px; position: absolute; margin: 390px 0 0 70px;"
        :style="{ 'background-color': hasHint ? 'var(--vt-c-indigo)' : 'grey', 'font-weight': wifiPassword===rightWifiPassword ? 'bold' : 'normal' }">Подключиться</button>
      </div>
      <div v-if="stage===3">
        <button v-if="substage4===0" @click="substage4++" style="position: absolute; width: 70px; height: 70px; margin: 407px 0 0 177px;" class="hint" :class="{ invisible: !hasHint }" />
        <input v-if="substage4===1" v-model="appName" style="position: absolute; width: 170px; height: 40px; margin: 75px 0 0 55px; font-size: large; border-radius: 10px;" placeholder="Поиск приложений">
        <button v-if="substage4===1" @click="appName.toLowerCase()===rightAppName ? substage4++ : null"
        style="position: absolute; width: 70px; height: 40px; margin: 75px 0 0 233px;"
        :style="{ 'background-color': appName.toLowerCase()===rightAppName ? 'blue' : 'lightblue' }">
          <p :style="{ 'font-weight': hasHint ? 'bold' : 'normal' }">Найти</p>
        </button>
        <button v-if="substage4===2" @click="substage4++" style="position: absolute; width: 250px; height: 80px; margin: 180px 0 0 55px;" class="hint" :class="{ invisible: !hasHint }" />
        <button v-if="substage4===3" @click="hasCompleted=true" style="position: absolute; width: 140px; height: 50px; margin: 195px 0 0 155px; border-radius: 30px; background-color: blue;">
          <p style="font-size: larger;" :style="{ 'font-weight': hasHint ? 'bold' : 'normal' }">Установить</p>
        </button>
      </div>
    </div>
  </main>
</template>
