<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  // Импорт элементов
  import {ref} from "vue"
  import VueCookies from "vue-cookies"
  import router from "@/router"
  import UsersDatabase from "./services/UsersDatabase"
  import Header from "./elements/Header_Element.vue"

  // Извлечение логина из куки
  const login = ref($cookies.get("login"))

  // Получение прогресса пользователя и его отправка в куки
  let progress
  UsersDatabase.getProgress(login.value).then(response => {
    progress = response.data
    $cookies.set("progress", progress)
    setupProgress()
  }).catch(e => console.log(e))

  // Объявление широт прогрессбаров (a - легкий, b - сложный)
  const width1a = ref("")
  const width1b = ref("")
  const width2a = ref("")
  const width2b = ref("")
  const width3a = ref("")
  const width3b = ref("")
  const width4a = ref("")
  const width4b = ref("")
  // Настройка прогрессбаров
  function setupProgress() {
    const progress1 = progress.progress1
    const maxProgress1a = 2
    width1a.value = `${Math.round(Math.min(progress1, maxProgress1a) / maxProgress1a * 100)}%`

    const maxProgress1b = 4
    width1b.value = `${Math.round(Math.min(progress1, maxProgress1b) / maxProgress1b * 100)}%`

    const progress2 = progress.progress2
    const maxProgress2a = 3
    width2a.value = `${Math.round(Math.min(progress2, maxProgress2a) / maxProgress2a * 100)}%`

    const maxProgress2b = 5
    width2b.value = `${Math.round(Math.min(progress2, maxProgress2b) / maxProgress2b * 100)}%`

    const progress3 = progress.progress3
    const maxProgress3a = 1
    width3a.value = `${Math.round(Math.min(progress3, maxProgress3a) / maxProgress3a * 100)}%`

    const maxProgress3b = 2
    width3b.value = `${Math.round(Math.min(progress3, maxProgress3b) / maxProgress3b * 100)}%`

    const progress4 = progress.progress4
    const maxProgress4a = 2
    width4a.value = `${Math.round(Math.min(progress4, maxProgress4a) / maxProgress4a * 100)}%`

    const maxProgress4b = 3
    width4b.value = `${Math.round(Math.min(progress4, maxProgress4b) / maxProgress4b * 100)}%`
  }
</script>

<template>
  <Header />
  <main>
    <div class = lesson-container>
      <svg width="900" height="150" class="lesson-background">
        <image href="./images/Lesson1.png" preserveAspectRatio="xMidYMid slice" />
      </svg>
      <div class="info-container" style="width: 900px;">
        <h1 class="title">Основы смартфона</h1>
        <div class="progress-line">
          <p>Лёгкий:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #E1FA71;">
              <div :style="{ 'background': '#A8BA2F','height': '15px', 'width': width1a }" />
            </div>
          </div>
          <p>Пройдено: {{ width1a }}</p>
          <button @click="router.replace('/lesson1/easy')"><p>Продолжить</p></button>
        </div>
        <div class="progress-line">
          <p>Сложный:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #B3F36D;">
              <div :style="{ 'background': '#A0D060','height': '15px', 'width': width1b }" />
            </div>
          </div>
          <p>Пройдено: {{ width1b }}</p>
          <button @click="router.replace('/lesson1/hard')"><p>Продолжить</p></button>
        </div>
      </div>
    </div>
    <div class = lesson-container>
      <svg width="900" height="150" class="lesson-background">
        <image href="./images/Lesson2.png" preserveAspectRatio="xMidYMid slice" />
      </svg>
      <div class="info-container" style="width: 900px;">
        <h1 class="title">Работа с месседжером MAX</h1>
        <div class="progress-line">
          <p>Лёгкий:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #689CD2;">
              <div :style="{ 'background': '#509090','height': '15px', 'width': width2a }" />
            </div>
          </div>
          <p>Пройдено: {{ width2a }}</p>
          <button @click="router.replace('/lesson2/easy')"><p>Продолжить</p></button>
        </div>
        <div class="progress-line">
          <p>Сложный:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #5EC4CD;">
              <div :style="{ 'background': '#30A0C0','height': '15px', 'width': width2b }" />
            </div>
          </div>
          <p>Пройдено: {{ width2b }}</p>
          <button @click="router.replace('/lesson2/hard')"><p>Продолжить</p></button>
        </div>
      </div>
    </div>
    <div class = lesson-container>
      <svg width="900" height="150" class="lesson-background">
        <image href="./images/Lesson3.png" preserveAspectRatio="xMidYMid slice" />
      </svg>
      <div class="info-container" style="width: 900px;">
        <h1 class="title">Онлайн покупки</h1>
        <div class="progress-line">
          <p>Лёгкий:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #C861D3;">
              <div :style="{ 'background': '#C050A0','height': '15px', 'width': width3a }" />
            </div>
          </div>
          <p>Пройдено: {{ width3a }}</p>
          <button @click="router.replace('/lesson3/easy')"><p>Продолжить</p></button>
        </div>
        <div class="progress-line">
          <p>Сложный:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #EF6C9A;">
              <div :style="{ 'background': '#D05070','height': '15px', 'width': width3b }" />
            </div>
          </div>
          <p>Пройдено: {{ width3b }}</p>
          <button @click="router.replace('/lesson3/hard')"><p>Продолжить</p></button>
        </div>
      </div>
    </div>
    <div class = lesson-container>
      <svg width="900" height="150" class="lesson-background">
        <image href="./images/Lesson4.png" preserveAspectRatio="xMidYMid slice" />
      </svg>
      <div class="info-container" style="width: 900px;">
        <h1 class="title">Госуслуги</h1>
        <div class="progress-line">
          <p>Лёгкий:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #7972D8;">
              <div :style="{ 'background': '#5050A0','height': '15px', 'width': width4a }" />
            </div>
          </div>
          <p>Пройдено: {{ width4a }}</p>
          <button @click="router.replace('/lesson4/easy')"><p>Продолжить</p></button>
        </div>
        <div class="progress-line">
          <p>Сложный:</p>
          <div style="width: 50%;">
            <div class="progress-bg" style="background: #FF7373;">
              <div :style="{ 'background': '#AA5050','height': '15px', 'width': width4b }" />
            </div>
          </div>
          <p>Пройдено: {{ width4b }}</p>
          <button @click="router.replace('/lesson4/hard')"><p>Продолжить</p></button>
        </div>
      </div>
    </div>
  </main>
</template>

<style scoped>
  main {
    display: grid;
    height: 800px;
    align-content: space-evenly;
  }
  .lesson-container, .info-container {
    height: 150px;
    display: grid;
    justify-items: center;
    align-content: space-evenly;
    p, .title {
      font-weight: bolder;
      text-align: center;
      text-shadow: 0px 0px 15px var(--color-background-mute);
    }
    .lesson-background {
      display: flex;
      position: absolute;
      z-index: -1;
      opacity: 0.7;
      border: 1px solid var(--color-background-mute);
      border-radius: 10px;
    }
    .progress-line {
      width: 90%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .progress-bg {
        height: 15px;
        border: 1px solid rgba(0, 0, 0, .5);
        border-radius: 10px;
        overflow: hidden;
      }
    }
  }
</style>
