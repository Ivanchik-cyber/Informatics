<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  // Импорт элементов
  import {ref, watch} from "vue"
  import router from "../router"
  import VueCookies from "vue-cookies"
  import UsersDatabase from "./services/UsersDatabase"

  // Создание переменных
  const login = ref("")
  const password = ref("")
  const isEnoughLengthLogin = ref(false)
  const isEnoughLengthPassword = ref(false)
  const isAllowedLettersLogin = ref(true)
  const isAllowedLettersPassword = ref(true)
  const hasNumber = ref(false)
  const hasLetter = ref(false)
  const isUnic = ref(true)

  // Получение всех зарегистрированных пользователей
  let allUserLogins = []
  function getUsersLogins() {
    UsersDatabase.getUsers()
    .then(response => {
      allUserLogins = response.data
    })
    .catch(e => console.log(e))
  }
  getUsersLogins()

  // Мгновенная проверка логина
  function updateLoginInfo() {
    isEnoughLengthLogin.value = login.value.length > 3
    isAllowedLettersLogin.value = true
    for (let i = 0; i < login.value.length; i++) {
      if (!login.value[i].match(/[a-z]/i) && !login.value[i].match(/[0-9]/i) && login.value[i] !== '_') {
        isAllowedLettersLogin.value = false
        break
      }
    }
    isUnic.value = true
    allUserLogins.forEach(element => {
      if (login.value === element.userLogin){
        isUnic.value = false
      }
    })
  }
  watch(login, updateLoginInfo)

  // Мгновенная проверка пароля
  function updatePasswordInfo() {
    isEnoughLengthPassword.value = password.value.length > 3
    isAllowedLettersPassword.value = true
    hasNumber.value = false
    hasLetter.value = false
    for (let i = 0; i < password.value.length; i++) {
      if (password.value[i].match(/[a-z]/i)) {
        hasLetter.value = true
      } else if (password.value[i].match(/[0-9]/i)) {
        hasNumber.value = true
      } else if (password.value[i] !== '_') {
        isAllowedLettersPassword.value = false
        break
      }
    }
  }
  watch(password, updatePasswordInfo)

  // Проверка информации перед регистрацией и вывод ошибок
  function checkData() {
    if (!login.value) {
      alert("Логин не может быть пустым!")
    } else if (!password.value) {
      alert("Пароль не может быть пустым!")
    } else if (!isEnoughLengthLogin.value) {
      alert("Логин не достаточной длины!")
    } else if (!isEnoughLengthPassword.value) {
      alert("Пароль не достаточной длины!")
    } else if (!isAllowedLettersLogin.value) {
      alert("Логин содержит недопустимые символы!")
    } else if (!isAllowedLettersPassword.value) {
      alert("Пароль содержит недопустимые символы!")
    } else if (!hasNumber.value) {
      alert("Пароль должен содержать хотя бы одну цифру!")
    } else if (!hasLetter.value) {
      alert("Пароль должен содержать хотя бы одну букву!")
    } else if (!isUnic.value) {
      alert("Логин должен быть уникальным!")
    } else {
      return true
    }
    return false
  }

  // Регистрация пользователя
  function createUser() {
    if (checkData()) {
      const user = {userLogin: login.value, userPassword: password.value}
      UsersDatabase.create(user)
      .catch(err => console.log(err))
      $cookies.set("login", login.value)
      getUsersLogins()
      router.replace("/main")
    }
  }

  // Вход пользователя
  function enter() {
    if (isUnic.value) {
      alert("Пользователя не существует!")
    } else {
      var isCorrect
      UsersDatabase.checkPassword(login.value, password.value)
      .then(response => {
        isCorrect = response.data
        if (isCorrect) {
          $cookies.set("login", login.value)
          router.replace("/main")
        } else {
          alert("Неверный пароль!")
        }
      })
      .catch(err => console.log(err))
    }
  }
</script>

<template>
  <main style="height: 100%;">
    <h1>Регистрация и вход</h1>
    <div id="form">
      <div id="login-password">
        <p>Введите логин</p>
        <input type="text" v-model="login" placeholder="Ваш логин">
        <p>Введите пароль</p>
        <input type="password" v-model="password" placeholder="Ваш пароль">
        <div>
          <button id="enter-button" @click="enter">Войти</button>
          <button id="register-button" @click="createUser">Зарегистрироваться</button>
        </div>
      </div>
      <div id="instruction">
        <p>Логин и пароль должны:</p>
        <ul>
          <li :class="{ available: isEnoughLengthLogin && isEnoughLengthPassword }">Быть длиннее трёх символов</li>
          <li :class="{ available: isAllowedLettersLogin && isAllowedLettersPassword }">Содержать только латинские буквы, цифры и нижнее подчёркивание</li>
          <li :class="{ available: hasNumber && hasLetter }">Пароль должен содержать хотя бы одну цифру и букву</li>
          <li :class="{ available: isUnic }">При регистрации логин должен быть уникальным</li>
        </ul>
      </div>
    </div>
  </main>
</template>

<style scoped>
  h1 {
    padding-top: 300px;
    text-align: center;
  }
  input {
    height: 50px;
    text-align: center;
    font-family: 'Segoe UI';
    font-size: medium;
    border: 1px solid var(--color-background-mute);
    border-radius: 5px;
  }
  li {
    font-size: medium;
    color: red;
  }
  .available {
    color: green;
  }
  #form {
    display: flex;
    margin: auto;
    margin-top: 20px;
    padding: 5px;
    height: 35%;
    width: 50%;
    background-color: var(--color-background-soft);
    border: 1px solid var(--color-background-mute);
    border-radius: 5px;
  }
  #login-password, #instruction {
    display: grid;
    justify-content: center;
    align-content: space-evenly;
    width: 50%;
  }
  #enter-button {
    width: 60px;
    height: 35px;
  }
  #register-button {
    width: 170px;
    margin-left: 10px;
    height: 35px;
  }
</style>
