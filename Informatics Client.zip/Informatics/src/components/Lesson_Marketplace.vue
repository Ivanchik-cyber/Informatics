<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  // Импорт
  import {ref, watch} from "vue"
  import VueCookies from "vue-cookies"
  import {useRoute, useRouter} from "vue-router"
  import UsersDatabase from "./services/UsersDatabase"
  import Header from "./elements/Header_Element.vue"
  import Thing from "./elements/Thing_Element.vue"

  // Получение метаданных
  const login = ref($cookies.get("login"))
  const progress = ref($cookies.get("progress").progress3)
  const difficult = ref(useRoute().params.difficult)
  const maxProgress = difficult.value === "easy" ? 1 : 2

  const hasCompleted = ref(false)
  const hasHint = ref(false)

  // Логика перехода
  const stage = ref(progress.value)
  if (stage.value >= maxProgress) {
    stage.value = maxProgress - 1;
  }
  watch(stage, () => {
    if (stage.value < 0) {
      stage.value = 0
    }
    if (stage.value < progress.value) {
      hasCompleted.value = true
    } else if (stage.value > progress.value) {
      UsersDatabase.updateProgress(login.value, "progress3")
      progress.value++;
      const newProgress = $cookies.get("progress")
      newProgress.progress3 = progress
      $cookies.set("progress", newProgress)
    }
  })

  const router = useRouter()
  function go() {
    hasCompleted.value = false
    stage.value++;
    if (stage.value === maxProgress) {
      router.replace("/main")
    }
  }

  // Вспомогательная часть

  const substage1 = ref(0) // Этап 1

  const offerName = ref("")
  const rightOfferName = ref("спрей от комаров")

  const delieverway = ref("") // Этап 2
  const payway = ref("")
  const callSecretCode = ref(false)
  const secretCode = ref(`${Math.floor(Math.random() * 1000)}`)
  const guessSecretCode = ref("")
</script>

<template>
  <Header />
  <main class="lesson">
    <div id="info-block">
      <svg width="500" height="100" class="lesson-background">
        <image href="./images/Lesson3.png"></image>
      </svg>
      <h1 class="title" style="padding-top: 20px;">Онлайн покупки</h1>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===0">Выбор товара на маркетплейсах</h2>
      <h2 class="subtitle" style="padding-top: 50px;" v-if="stage===1">Оформление доставки</h2>
      <div class="info">
        <div class="info-part" v-if="stage===0">
          <p>Маркетплейс - это электронный магазин.</p>
          <p>На нём можно выбирать и заказывать товары.</p>
          <p>На карточке товара написаны название товара, продавец, его рейтинг и цена.</p>
          <ol>
            <li style="font-size: large;">Зайдите в WildBerries (Вайлдберрис).</li>
            <li style="font-size: large;">Введите в поиск "спрей от комаров".</li>
            <li style="font-size: large;">Поместите в корзину спрей от продавца "Птичка".</li>
          </ol>
          <p class="task">Поместите спрей в корзину.</p>
        </div>
        <div class="info-part" v-if="stage===1">
          <p>После выбора товаров, которые вы хотите купить, надо оформить доставку.</p>
          <ol>
            <li style="font-size: large;">Сначала выберете способ доставки: курьер (привезёт прямо к вашей квартире, никуда ходить не нужно) или пункт выдачи заказов (привезут на него, и вам придётся идти туда).</li>
            <li style="font-size: large;">Выберете адрес квартиры/адрес пункта выдачи.</li>
            <li style="font-size: large;">Выберете способ оплаты: карта/при получении/СБП (система быстрых платежей).</li>
            <li style="font-size: large;">Затем вам прийдёт код подтверждения, введите его.</li>
            <p>Внимание! Никому не сообщайте ваш код подтверждения!</p>
          </ol>
          <p class="task">Оформите доставку.</p>
        </div>
      </div>
      <button id="help-button" @click="hasHint=!hasHint">Помощь</button>
      <button id="back-button" @click="stage--">Назад</button>
      <button id="go-button" @click="go" :disabled="!hasCompleted">Вперёд</button>
      <button id="menu-button" @click="router.replace('/main')">В меню</button>
    </div>
    <div id="interactive-block">
      <svg width="360" height="700" class="lesson-image">
        <image href="./images/Lesson 2.1.png" v-if="stage===0&&substage1===0" />
        <image href="./images/Lesson 3.1.png" v-if="stage===0&&(substage1===1||substage1===2)" />
        <image href="./images/Lesson 3.1.png" v-if="stage===1" />
      </svg>
      <div v-if="stage===0">
        <button v-if="substage1===0" @click="substage1++" style="position: absolute; width: 70px; height: 70px; margin: 407px 0 0 252px;" class="hint" :class="{ invisible: !hasHint }" />
        <input v-if="substage1===1||substage1===2" v-model="offerName" style="position: absolute; width: 200px; height: 40px; margin: 150px 0 0 25px; font-size: large; border-radius: 10px; text-align: center;" placeholder="Поиск приложений">
        <button v-if="substage1===1||substage1===2" @click="offerName.toLowerCase()===rightOfferName ? substage1++ : null; rightOfferName=null"
        style="position: absolute; width: 75px; height: 40px; margin: 150px 0 0 240px;"
        :style="{ 'background-color': offerName.toLowerCase()===rightOfferName ? 'blue' : 'lightblue' }">
          <p :style="{ 'font-weight': hasHint ? 'bold' : 'normal' }">Найти</p>
        </button>
        <Thing v-if="substage1===1" background="lightpink" thingName="Сумка женская" cost="70000" seller="Gucci" reviesCount="684" rate="5.0" style="margin: 220px 0 0 25px;" />
        <Thing v-if="substage1===1" background="lightskyblue" thingName="Оперативная память 16ГБ" cost="120000" seller="AMD" reviesCount="37" rate="3.4" style="margin: 320px 0 0 25px;" />
        <Thing v-if="substage1===1" background="lightgrey" thingName="Цемент 4кг" cost="5000" seller="И. Иванов" reviesCount="253" rate="4.3" style="margin: 420px 0 0 25px;" />
        <Thing v-if="substage1===1" background="lightyellow" thingName="Витамин D3" cost="3000" seller="АРГО" reviesCount="590" rate="3.8" style="margin: 520px 0 0 25px;" />
        <Thing v-if="substage1===2" background="lightgoldenrodyellow" thingName="Спрей от комаров" cost="500" seller="Клещ" reviesCount="54" rate="4.2" style="margin: 220px 0 0 25px;" />
        <Thing v-if="substage1===2" background="lightgreen" thingName="Спрей от комаров" cost="750" seller="Птичка" reviesCount="89" rate="4.3" :onClick="() => hasCompleted=true" :buttonColor="hasHint ? 'red' : 'azure'" style="margin: 320px 0 0 25px;" />
        <Thing v-if="substage1===2" background="lightseagreen" thingName="Спрей против насекомых" cost="349" seller="Заяц" reviesCount="13" rate="4.1" style="margin: 420px 0 0 25px;" />
        <Thing v-if="substage1===2" background="lightsalmon" thingName="Назальный спрей" cost="540" seller="АРГО" reviesCount="125" rate="4.8" style="margin: 520px 0 0 25px;" />
      </div>
      <div v-if="stage===1">
        <span v-if="callSecretCode" style="position: absolute; color: black; background-color: azure; padding: 10px; border-radius: 15px; margin: 30px 0 0 30px;"><p>Код подтверждения: {{ secretCode }}</p></span>
        <p style="position: absolute; font-size: xx-large; color: black; margin: 130px 0 0 105px;">Доставка</p>
        <p style="position: absolute; font-size: larger; color: black; margin: 200px 0 0 100px;">Способ доставки</p>
        <select v-model="delieverway" style="position: absolute; font-size: large; color: black; height: 30px; margin: 250px 0 0 70px;">
          <option value="deliever">Курьер</option>
          <option value="self">Пункт выдачи заказов</option>
        </select>
        <p style="position: absolute; font-size: larger; color: black; margin: 330px 0 0 110px;">Способ оплаты</p>
        <select v-model="payway" style="position: absolute; font-size: large; color: black; height: 30px; margin: 380px 0 0 100px;">
          <option value="card">Карта</option>
          <option value="gain">При получении</option>
          <option value="cbp">СБП</option>
        </select>
        <button @click="delieverway&&payway ? callSecretCode=true : null" style="position: absolute; font-size: larger; color: black; height: 50px; width: 290px; margin: 450px 0 0 30px;" :style="{ background: hasHint ? 'red' : 'blueviolet', 'font-weight': delieverway&&payway ? 'bold' : 'normal' }">Получить код подтверждения</button>
        <input v-model="guessSecretCode" style="position: absolute; width: 150px; height: 40px; margin: 530px 0 0 30px; font-size: large; border-radius: 10px; text-align: center;" placeholder="Введите код">
        <button @click="hasCompleted=guessSecretCode===secretCode" style="position: absolute; font-size: larger; color: black; height: 40px; width: 110px; margin: 530px 0 0 210px;" :style="{ background: hasHint ? 'red' : 'violet', 'font-weight': guessSecretCode===secretCode ? 'bold' : 'normal' }">Проверить</button>
      </div>
    </div>
  </main>
</template>
