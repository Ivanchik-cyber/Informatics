import http from "./HttpService.js"

class UserDataBase {
  getUsers() {
    return http.get("/users")
  }
  getProgress(login) {
    return http.get(`/users/${login}/progress`)
  }
  checkPassword(login, password) {
    return http.get(`/users/${login}/password/${password}`)
  }
  create(data) {
    return http.post("/users", data)
  }
  updateProgress(login, progressNumber) {
    return http.put(`/users/${login}/progress/${progressNumber}`)
  }
  deleteProgress(login, progressNumber) {
    return http.put(`/users/${login}/progress/${progressNumber}/delete`)
  }
}

export default new UserDataBase()
