<!-- eslint-disable no-unused-vars -->
<!-- eslint-disable no-undef -->
<script setup>
  import {ref} from "vue"
  import VueCookies from "vue-cookies"
  import router from "@/router"

  const login = ref($cookies.get("login"))

  // Завершение сессии и отправка на страницу регистрации
  function exit() {
    $cookies.remove("login")
    login.value = null
    router.replace("/")
  }
</script>

<template>
  <header>
    <h1 id="title">Информатикс</h1>
    <div id="info">
      <p id="login">{{ login }}</p>
      <button id="exit-button" @click="exit">Выйти</button>
    </div>
  </header>
</template>

<style scoped>
  header {
    height: 55px;
    display: flex;
    background-color: var(--color-background-soft);
    border: 1px solid var(--color-background-mute);
    align-items: center;
  }
  #title {
    width: 85%;
    text-align: center;
  }
  #info {
    display: grid;
    width: 15%;
    justify-items: center;
  }
  #login {
    width: auto;
    text-align: center;
  }
  #exit-button {
    width: 80%;
  }
</style>
