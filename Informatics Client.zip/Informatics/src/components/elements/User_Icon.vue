<script setup>
  const props = defineProps(["background", "userBackground", "userName", "userPs"])
</script>

<template>
  <span style="position: absolute; width: 300px; height: 80px; border-radius: 10px;" :style="{ background: props.background }" class="hover">
    <span style="position: absolute; width: 60px; height: 60px; margin: 10px; border-radius: 100%;" :style="{ background: props.userBackground }">
      <span style="position: absolute; width: 30px; height: 30px; background-color: aliceblue; margin: 5px 0 0 15px; border-radius: 100%;" />
      <span style="position: absolute; width: 40px; height: 20px; background-color: aliceblue; margin: 30px 0 0 10px; border-radius: 20px 20px 0 0;" />
    </span>
    <p style="font-size: x-large; width: calc(100% - 80px); margin: 0 0 0 80px; color: lightgray;">{{ props.userName }}</p>
    <p style="font-size: large; width: calc(100% - 80px); margin: 0 0 0 80px;">{{ props.userPs }}</p>
  </span>
</template>
