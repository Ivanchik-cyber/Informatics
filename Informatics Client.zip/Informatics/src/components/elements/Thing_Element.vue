<script setup>
  const props = defineProps(["background", "thingName", "cost", "seller", "reviesCount", "rate", "onClick", "buttonColor"])
</script>

<template>
  <span style="position: absolute; width: 300px; height: 90px; border-radius: 10px; color: black; border: 1px solid black;" :style="{ background: props.background }" class="hover">
    <p style="font-size: larger; font-weight: bold;">{{ props.thingName }}</p>
    <p style="position: absolute; width: 100%; text-align: right; padding-right: 20px; font-weight: bold;">{{ props.cost }}₽</p>
    <p style="text-align: left; margin-left: 20px;">Продавец - {{ props.seller }}</p>
    <button @click="onClick" style="position: absolute; color: white; margin-left: 250px;" :style="{ 'background-color': buttonColor || 'azure' }">🛒</button>
    <p style="text-align: left; margin-left: 20px;">{{ props.reviesCount }} отзывов - {{ props.rate }}⭐</p>
  </span>
</template>
