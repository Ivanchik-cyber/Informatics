// Конфигурация подключения
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "rdfsjc9:-)",
  DB: "users",
}
